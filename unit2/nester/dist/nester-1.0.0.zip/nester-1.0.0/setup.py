from distutils.core import setup

setup(
    name = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'skandpurohit',
    author_email = 'skandpurohit@gmail.com',
    url = 'https://github.com/skandpurohit/myDir',
    description = 'A simple printer of nested lists',
    )
